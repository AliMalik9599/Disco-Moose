## HW4 Write Up

In HW4, we added new routes to the server to list all book in the database and add a new book. In adding a new book, we also  added a new author if it was not already listed in the database. We added two new .vm files called books.vm and addbook.vm which corresponded to the new routes we added. We initially had issues with the post method for /addbook and had to figure out how to determine if an author already exsited in the database. We decided to get a list of all the authors and then loop through each one to see if the name matched the input from the frontend. If they did, we got that author id and inserted the book into the database. If the author didn't exist, we added them and used the new id to add the book to the database. 

We also set a cookie for color to make the welcome page title styling change. Lastly, we restricted viewing access to the lists of authors, books and ability to add new authors and books to users who were logged in. If a non-logged in user tried to access the information, they were authomatically rerouted to the signin page.

Group members: Katie Newbold, Simone Bliss, Devin Ramsden, Mia Boloix, Justin Greene, Ali Malik

### MyBooksApp

This is a simple application we build during lectures in fall 2020 OOSE class together to practice with various concepts and technologies. This 
is a web app conforming to Client-Server Architecture where user(s) can store their favorite books and authors. The app
will store data in a database and its backend functionalities are implemented as RESTful API end-points.